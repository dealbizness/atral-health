import React, { useState, useEffect } from 'react';
import {
  Activity,
  ShieldCheck,
  Zap,
  BarChart3,
  Clock,
  ArrowRight,
  ChevronRight,
  Menu,
  X,
  Database,
  Search,
  CheckCircle2,
  TrendingUp,
  FileText,
} from 'lucide-react';

const App = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const services = [
    {
      title: 'Precision Medical Coding',
      description:
        'ICD-10, CPT, and HCPCS coding with 99% accuracy to eliminate claim rejections at the source.',
      icon: <FileText className="w-8 h-8 text-blue-400" />,
      features: ['Daily Chart Audits', 'HCC & Risk Adjustment', 'EHR Agnostic'],
    },
    {
      title: 'Full-Cycle Billing',
      description:
        'End-to-end claim management from patient registration to final reimbursement.',
      icon: <Database className="w-8 h-8 text-indigo-400" />,
      features: [
        'Clean Claim Scrubbing',
        'Denial Management',
        'Secondary Claims',
      ],
    },
    {
      title: 'Post-Payment Recovery',
      description:
        "We don't just bill; we audit. Reclaiming revenue lost to underpayments and silent denials.",
      icon: <Search className="w-8 h-8 text-cyan-400" />,
      features: [
        'Contractual Underpayments',
        'Zero-Balance Audits',
        'Appeal Advocacy',
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-blue-500/30">
      {/* Navigation */}
      <nav
        className={`fixed w-full z-50 transition-all duration-300 ${
          scrolled
            ? 'bg-slate-950/90 backdrop-blur-md py-4 border-b border-slate-800'
            : 'bg-transparent py-6'
        }`}
      >
        <div className="container mx-auto px-6 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center shadow-lg shadow-blue-500/20">
              <Zap className="text-white w-6 h-6 fill-white" />
            </div>
            <span className="text-2xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white to-slate-400">
              ATRAL <span className="font-light">HEALTH</span>
            </span>
          </div>

          <div className="hidden md:flex items-center gap-8">
            <a
              href="#services"
              className="text-sm font-medium hover:text-blue-400 transition-colors"
            >
              Services
            </a>
            <a
              href="#solutions"
              className="text-sm font-medium hover:text-blue-400 transition-colors"
            >
              Solutions
            </a>
            <a
              href="#about"
              className="text-sm font-medium hover:text-blue-400 transition-colors"
            >
              About Us
            </a>
            <button className="bg-white text-slate-950 px-6 py-2 rounded-full text-sm font-bold hover:bg-blue-50 transition-all transform hover:scale-105 active:scale-95">
              Get a Free Audit
            </button>
          </div>

          <button
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X /> : <Menu />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-40 bg-slate-950 pt-24 px-6 md:hidden">
          <div className="flex flex-col gap-6">
            <a
              href="#services"
              className="text-xl font-semibold"
              onClick={() => setIsMenuOpen(false)}
            >
              Services
            </a>
            <a
              href="#solutions"
              className="text-xl font-semibold"
              onClick={() => setIsMenuOpen(false)}
            >
              Solutions
            </a>
            <a
              href="#about"
              className="text-xl font-semibold"
              onClick={() => setIsMenuOpen(false)}
            >
              About Us
            </a>
            <button className="bg-blue-600 text-white p-4 rounded-xl font-bold mt-4">
              Book Consultation
            </button>
          </div>
        </div>
      )}

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full -z-10 overflow-hidden">
          <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-600/10 blur-[120px] rounded-full"></div>
          <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-indigo-600/10 blur-[120px] rounded-full"></div>
        </div>

        <div className="container mx-auto px-6 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-sm font-medium mb-8 animate-fade-in">
            <Activity className="w-4 h-4" />
            <span>AI-Powered Revenue Cycle Optimization</span>
          </div>

          <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight mb-6 leading-tight max-w-4xl mx-auto">
            Beyond Billing. <br />
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-400 via-indigo-400 to-cyan-400">
              Total Revenue Intelligence.
            </span>
          </h1>

          <p className="text-lg md:text-xl text-slate-400 max-w-2xl mx-auto mb-10 leading-relaxed font-light">
            Atral Health transforms your medical practice's financial DNA. We
            combine expert medical coding with predictive analytics to capture
            every dollar you've earned.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <button className="w-full sm:w-auto px-8 py-4 bg-blue-600 text-white rounded-xl font-bold shadow-xl shadow-blue-900/40 hover:bg-blue-500 transition-all flex items-center justify-center gap-2">
              Accelerate My Revenue <ArrowRight className="w-5 h-5" />
            </button>
            <button className="w-full sm:w-auto px-8 py-4 bg-slate-900 border border-slate-700 rounded-xl font-bold hover:bg-slate-800 transition-all">
              Watch Demo
            </button>
          </div>

          {/* Interactive Mockup */}
          <div className="mt-20 relative max-w-5xl mx-auto group">
            <div className="absolute -inset-1 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl blur opacity-25 group-hover:opacity-40 transition duration-1000"></div>
            <div className="relative bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl p-4 md:p-8">
              <div className="flex flex-col md:flex-row gap-8">
                <div className="flex-1 space-y-6">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-slate-300">
                      Revenue Snapshot
                    </h3>
                    <span className="text-xs text-green-400 font-mono bg-green-400/10 px-2 py-1 rounded">
                      LIVE UPDATES
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                      <p className="text-slate-500 text-xs mb-1">
                        Clean Claim Rate
                      </p>
                      <p className="text-2xl font-bold text-blue-400">98.4%</p>
                      <TrendingUp className="w-4 h-4 text-green-400 mt-2" />
                    </div>
                    <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                      <p className="text-slate-500 text-xs mb-1">
                        Denial Reduction
                      </p>
                      <p className="text-2xl font-bold text-indigo-400">
                        -42.1%
                      </p>
                      <div className="h-1 bg-slate-800 rounded-full mt-4 overflow-hidden">
                        <div className="h-full bg-indigo-500 w-3/4"></div>
                      </div>
                    </div>
                  </div>
                  <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 h-32 flex items-end gap-2">
                    {[40, 70, 45, 90, 65, 80, 100].map((h, i) => (
                      <div
                        key={i}
                        className="flex-1 bg-blue-600/30 border border-blue-500/50 rounded-t-sm"
                        style={{ height: `${h}%` }}
                      ></div>
                    ))}
                  </div>
                </div>
                <div className="md:w-64 space-y-4">
                  <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-8 h-8 rounded bg-green-500/10 flex items-center justify-center">
                        <CheckCircle2 className="w-4 h-4 text-green-500" />
                      </div>
                      <span className="text-sm font-medium">
                        Compliance Guard
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 leading-relaxed">
                      System-wide check complete. 0 HIPAA vulnerabilities found.
                    </p>
                  </div>
                  <div className="p-4 rounded-xl bg-blue-600 shadow-lg shadow-blue-900/20">
                    <p className="text-white/80 text-xs mb-2 underline decoration-white/30">
                      Action Required
                    </p>
                    <p className="text-white font-bold text-sm">
                      3 Underpayments detected in BlueCross claims. Tap to
                      appeal.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-24 bg-slate-950">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold mb-4">
              End-to-End RCM Excellence
            </h2>
            <p className="text-slate-400 max-w-xl mx-auto">
              From the moment a patient schedules to the final dollar collected,
              Atral Health ensures a seamless financial journey.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {services.map((service, idx) => (
              <div
                key={idx}
                className="group p-8 bg-slate-900 border border-slate-800 rounded-3xl hover:border-blue-500/50 hover:bg-slate-900/50 transition-all duration-300 transform hover:-translate-y-2"
              >
                <div className="mb-6 p-4 bg-slate-950 rounded-2xl w-fit group-hover:scale-110 transition-transform">
                  {service.icon}
                </div>
                <h3 className="text-xl font-bold mb-4 group-hover:text-blue-400 transition-colors">
                  {service.title}
                </h3>
                <p className="text-slate-400 mb-6 font-light leading-relaxed">
                  {service.description}
                </p>
                <ul className="space-y-3">
                  {service.features.map((f, i) => (
                    <li
                      key={i}
                      className="flex items-center gap-3 text-sm text-slate-300"
                    >
                      <div className="w-1.5 h-1.5 rounded-full bg-blue-500"></div>
                      {f}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trust/Proof Section */}
      <section className="py-20 border-t border-slate-900">
        <div className="container mx-auto px-6 grid md:grid-cols-4 gap-12">
          <div className="text-center">
            <p className="text-4xl font-bold text-white mb-2">99%</p>
            <p className="text-slate-500 text-sm uppercase tracking-widest">
              Coding Accuracy
            </p>
          </div>
          <div className="text-center">
            <p className="text-4xl font-bold text-white mb-2">&lt;15</p>
            <p className="text-slate-500 text-sm uppercase tracking-widest">
              Avg. A/R Days
            </p>
          </div>
          <div className="text-center">
            <p className="text-4xl font-bold text-white mb-2">+25%</p>
            <p className="text-slate-500 text-sm uppercase tracking-widest">
              Revenue Increase
            </p>
          </div>
          <div className="text-center">
            <p className="text-4xl font-bold text-white mb-2">24/7</p>
            <p className="text-slate-500 text-sm uppercase tracking-widest">
              Support Access
            </p>
          </div>
        </div>
      </section>

      {/* Features Detail */}
      <section className="py-24 bg-slate-900/30">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row items-center gap-16">
            <div className="flex-1">
              <span className="text-blue-500 font-bold tracking-widest text-xs uppercase mb-4 block">
                Modern Infrastructure
              </span>
              <h2 className="text-4xl font-bold mb-6 leading-tight">
                The Tech Stack That <br />
                Future-Proofs Your Practice.
              </h2>
              <div className="space-y-8 mt-10">
                <div className="flex gap-4">
                  <div className="mt-1 flex-shrink-0">
                    <ShieldCheck className="w-6 h-6 text-green-400" />
                  </div>
                  <div>
                    <h4 className="font-bold text-lg mb-1">
                      HIPAA Sovereign Security
                    </h4>
                    <p className="text-slate-400 font-light">
                      Bank-grade encryption for patient PHI, hosted on sovereign
                      cloud environments.
                    </p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="mt-1 flex-shrink-0">
                    <Clock className="w-6 h-6 text-blue-400" />
                  </div>
                  <div>
                    <h4 className="font-bold text-lg mb-1">
                      Real-Time Denial Response
                    </h4>
                    <p className="text-slate-400 font-light">
                      Our engine identifies denials the second they post, often
                      appealing them before you check your morning email.
                    </p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="mt-1 flex-shrink-0">
                    <BarChart3 className="w-6 h-6 text-indigo-400" />
                  </div>
                  <div>
                    <h4 className="font-bold text-lg mb-1">
                      Executive Dashboards
                    </h4>
                    <p className="text-slate-400 font-light">
                      Full transparency. Monitor your cash flow from your phone
                      with detailed breakdown by payer and provider.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex-1 relative">
              <div className="absolute inset-0 bg-blue-600/20 blur-[80px] rounded-full"></div>
              <div className="relative border border-slate-800 bg-slate-950/80 backdrop-blur p-6 rounded-3xl shadow-2xl">
                <div className="flex items-center gap-4 mb-6 pb-6 border-b border-slate-800">
                  <div className="w-12 h-12 rounded-full bg-slate-800 overflow-hidden flex items-center justify-center">
                    <Activity className="text-blue-400 w-6 h-6" />
                  </div>
                  <div>
                    <p className="font-bold">Atral Intel Engine</p>
                    <p className="text-xs text-slate-500">
                      Processing Claims...
                    </p>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="flex justify-between items-center text-sm p-3 rounded-lg bg-slate-900 border border-slate-800">
                    <span>BlueCross/Shield</span>
                    <span className="text-green-400 font-bold">
                      $12,400 PAID
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-sm p-3 rounded-lg bg-slate-900 border border-slate-800">
                    <span>United Health</span>
                    <span className="text-yellow-400 font-bold">IN REVIEW</span>
                  </div>
                  <div className="flex justify-between items-center text-sm p-3 rounded-lg bg-blue-600/20 border border-blue-500/30">
                    <span className="font-medium italic">
                      Atral Optimization Tip:
                    </span>
                    <span className="text-xs px-2 py-1 bg-blue-500 rounded-full">
                      NEW
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 p-2 italic leading-relaxed">
                    "Dr. Smith: We've identified a recurring missing modifier on
                    CPT 99214. Correcting now will increase revenue by
                    $1.2k/month."
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24">
        <div className="container mx-auto px-6">
          <div className="bg-gradient-to-br from-blue-700 to-indigo-900 rounded-[3rem] p-12 md:p-20 text-center relative overflow-hidden group shadow-2xl shadow-blue-500/20">
            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
            <h2 className="text-4xl md:text-6xl font-bold mb-8 relative z-10 leading-tight">
              Stop Guessing Your Profits. <br />
              Start Capturing Them.
            </h2>
            <p className="text-blue-100 text-lg mb-10 max-w-2xl mx-auto relative z-10 font-light opacity-90">
              Join 50+ practices already using Atral Health to stabilize their
              revenue and focus on what matters most: patient care.
            </p>
            <button className="relative z-10 px-10 py-5 bg-white text-blue-900 rounded-2xl font-black text-xl hover:bg-blue-50 transition-all shadow-xl hover:shadow-2xl flex items-center gap-3 mx-auto">
              Free Revenue Audit <ChevronRight />
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-slate-900">
        <div className="container mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-2 grayscale hover:grayscale-0 transition-all cursor-pointer">
            <Zap className="text-blue-500 w-6 h-6 fill-blue-500" />
            <span className="text-xl font-bold tracking-tight">
              ATRAL HEALTH
            </span>
          </div>
          <p className="text-slate-500 text-sm">
            © 2026 Atral Health RCM Solutions. All Rights Reserved.
          </p>
          <div className="flex gap-6 text-sm text-slate-400">
            <a href="#" className="hover:text-white transition-colors">
              Privacy
            </a>
            <a href="#" className="hover:text-white transition-colors">
              HIPAA Policy
            </a>
            <a href="#" className="hover:text-white transition-colors">
              Contact
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
